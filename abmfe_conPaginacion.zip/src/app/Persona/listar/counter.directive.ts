import { Directive, Input, SimpleChanges, TemplateRef, ViewContainerRef } from "@angular/core";


@Directive({
  selector: '[counterOf]'
})
export class CounterDirective{

//  ViewContainerRef: es la parte del HTML donde el ng-template aparece y representa el lugar ocupado por ng-template y
//  metodos y propiedades del ViewContainerRef:
//  - createEmbeddedView(template) : ve el texto, acepta argumentos opcionales, y acepta la posicion donde deberia ser insertado
//  - clear()
//  - lenght : devuelve la cantidad de views del container
//  - get(index), insert(view, index), remove(index) ....
// TemplateRef: es el objeto que representa el contenido del elemnento del ng-tempate


  constructor(private container: ViewContainerRef, private template: TemplateRef<Object>){}

  @Input('counterOf')
  counter:number;
// ngOnInit, ngDoCheck, ngOnDestroy ... el resto de los metodos del ciclo de vida -- LifeCycle Hooks
ngOnChanges(changes: SimpleChanges){
  this.container.clear();
  for (let i=0; i< this.counter; i++){
    this.container.createEmbeddedView(
      this.template, new CounterDirectiveContext(i+1)
    );
  }
}

}

class CounterDirectiveContext{
  constructor(public $implicit: any){}
}
