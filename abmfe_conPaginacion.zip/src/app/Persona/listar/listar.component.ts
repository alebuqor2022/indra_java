import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Persona } from 'src/app/Modelo/persona';
import { ServiceService } from 'src/app/Service/service.service';

@Component({
  selector: 'app-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.css']
})
export class ListarComponent implements OnInit {

  personas: Persona[] | undefined;
  public personasPerPage =4;
  public selectedPage=1;

  constructor(private router:Router, private service: ServiceService) { }

  ngOnInit(): void {
    this.service.getPersonas().subscribe(data=>this.personas = data);
  }

  editar(persona: Persona ){
    localStorage.setItem('id', persona.id.toString() );
    this.router.navigate(['edit']);
  }

  delete(persona: Persona){
    this.service.deletePersona(persona).subscribe(data=>
      this.personas = this.personas.filter(p => p!==persona));
      alert("Persona eliminada !!!");
  }

  get personas2(){
    this.service.getPersonas().subscribe(data=>this.personas = data);
    let pageIndex= (this.selectedPage -1 ) * this.personasPerPage;
    console.log("pageIndex: " +pageIndex );
    return this.personas.slice(pageIndex, pageIndex + this.personasPerPage);

  }
  // get pageNumbers(): number[]{
  //   return Array(this.personas.length/this.personasPerPage)
  //   .fill(0).map((x,i)=> i+1);
  // }

  get pageCount(){
    return this.personas.length/this.personasPerPage;
  }

  changePage(newPage: number){
    this.selectedPage=newPage;
  }

 // changePageSize(event: any){
//    let newSize=event.target.value;
    changePageSize(newSize: number){
    this.personasPerPage=Number(newSize);
    this.changePage(1);
  }

}
