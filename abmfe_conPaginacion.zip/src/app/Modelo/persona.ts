export class Persona{

id:number |undefined;
public nombre:string |undefined;
public apellido:string |undefined;

// constructor(){}
//constructor(id:number |undefined, public nombre:string, public apellido:string  ){}

}
