import {Person} from "./person";

fdescribe("Testeo de person",()=>{

  describe("Testeo para Edad",()=>{
    it("debe devolver 45",()=>{
      // AAA --> ARRANGE, ACT, ASSERT
      //ARRANGE
      const person = new Person("Ale", 35,"Buq");
      //ACT
      const edad=person.getAgeInYears(10);
      //ASSERT
      expect(edad).toEqual(45);
    });
    it("debe devolver 35",()=>{
      const person=new Person('Ale',22,'Buq');
      const edad=person.getAgeInYears(10);
      expect(edad).toEqual(35);
    });
  });
  describe("Testeo para Nombres",()=>{
    it("debe devolver Nombre Apellido",()=>{
      const person = new Person("Ale", 35,"Buq");
      const rpta=person.getFullName();
      expect(rpta).toEqual('Ale Buq');
    });
    it("debe devolver Nombre+Apellido",()=>{
      const person = new Person("Ale", 35,"Buq");
      const rpta=person.getFullName();
      expect(rpta).toEqual('Ale+Buq');
    });
  });

})
