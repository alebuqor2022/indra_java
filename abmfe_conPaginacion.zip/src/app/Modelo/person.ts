export class Person{

  constructor(
    public name: string,
    public age: number,
    public apellido: string){}

  getAgeInYears(years: number):number{
    return this.age + years;
  }

  getFullName():string{
    return `${this.name} ${this.apellido}`;
  }

  getDatos():string{
    return this.name + " " + this.apellido;
  }
}
